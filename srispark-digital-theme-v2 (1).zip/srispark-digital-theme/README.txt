=== SriSpark Digital Tech WordPress Theme ===

This is a classic WordPress theme folder. Its required theme files are:
* style.css — theme information and the page's design.
* index.php — the complete one-page storefront and WordPress page structure.
* functions.php — theme setup and loading of the design and copy-button script.
* assets/images/ — the hero artwork and all 12 product posters.
* assets/js/theme.js — the GPay number copy-button behavior.

The separate header.php, footer.php, and front-page.php files are not required: the
one-page layout is contained in index.php, with wp_head(), wp_body_open(), and
wp_footer() included in the correct places. The page works as the theme homepage.

Included: 12 digital product posters, starting-from ₹999 pricing, WhatsApp ordering,
GPay 9842182212, six launch testimonials, contact details and social links.

INSTALL
1. Keep the folder name srispark-digital-theme. Do not zip only the files inside it.
2. Create a ZIP containing that folder at its top level.
3. In WordPress, open Appearance > Themes > Add New Theme > Upload Theme.
4. Select the ZIP, choose Install Now, then Activate.
5. Open the site's homepage and confirm the theme is active.

If WordPress says the theme is missing a stylesheet, the ZIP likely has an extra
folder level or style.css is not directly inside srispark-digital-theme/.

The theme replaces the current theme's appearance. Save a backup before activation.
The testimonials and client statistics are the provided launch-page content; confirm
they are accurate and authorized before publishing.
