(function () {
  'use strict';

  function copyText(value) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(value);
    }
    return new Promise(function (resolve, reject) {
      var field = document.createElement('textarea');
      field.value = value;
      field.setAttribute('readonly', '');
      field.style.position = 'fixed';
      field.style.opacity = '0';
      document.body.appendChild(field);
      field.select();
      var copied = document.execCommand('copy');
      document.body.removeChild(field);
      copied ? resolve() : reject(new Error('Copy failed'));
    });
  }

  document.querySelectorAll('.js-copy-gpay').forEach(function (button) {
    button.addEventListener('click', function () {
      var label = button.querySelector('span');
      if (!label) return;
      var original = label.textContent;
      copyText(button.getAttribute('data-gpay') || '9842182212')
        .then(function () { label.textContent = 'Copied'; })
        .catch(function () { label.textContent = 'Copy failed'; })
        .then(function () {
          window.setTimeout(function () { label.textContent = original; }, 1800);
        });
    });
  });
}());
