<?php
/**
 * SriSpark Digital Tech — landing page.
 *
 * @package srispark-digital
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$img = function ( $file ) {
	return esc_url( get_theme_file_uri( 'assets/images/' . $file ) );
};

$products = array(
	array(
		'name'        => 'ChatGPT Prompt Engineering Mastery',
		'tag'         => '1,000 Prompts',
		'price'       => '₹999',
		'description' => '1,000 professional ChatGPT prompts for business, marketing, content and productivity.',
		'image'       => 'chatgpt-prompt-mastery.jpg',
		'accent'      => 'brand',
	),
	array(
		'name'        => 'Digital Freelancer Launch Kit',
		'tag'         => '16 Modules',
		'price'       => '₹999',
		'description' => 'The complete system to start, brand and grow your freelance business — with bonus vault.',
		'image'       => 'freelancer-launch-kit.jpg',
		'accent'      => 'accent',
	),
	array(
		'name'        => 'Reels Content Machine',
		'tag'         => '365 Days',
		'price'       => '₹999',
		'description' => '365 days of Instagram reels — a plug-and-play content system with 6 content pillars.',
		'image'       => 'reels-content-machine.jpg',
		'accent'      => 'cyan',
	),
	array(
		'name'        => 'SEO AI Prompt Vault',
		'tag'         => '300+ Prompts',
		'price'       => '₹999',
		'description' => '300+ AI prompts for faster, smarter and scalable SEO across 15 power-packed modules.',
		'image'       => 'seo-ai-prompt-vault.jpg',
		'accent'      => 'brand',
	),
	array(
		'name'        => 'Canva Digital Product Empire Kit',
		'tag'         => '15 Modules',
		'price'       => '₹999',
		'description' => 'Create, package and sell digital products with Canva — plus an 8-part bonus stack.',
		'image'       => 'canva-empire-kit.jpg',
		'accent'      => 'accent',
	),
	array(
		'name'        => 'AI Business Toolkit 2026',
		'tag'         => '12 AI Systems',
		'price'       => '₹999',
		'description' => 'The ultimate AI-powered business growth system — 50+ workflows and 100+ prompts.',
		'image'       => 'ai-business-toolkit.jpg',
		'accent'      => 'cyan',
	),
	array(
		'name'        => 'Faceless Creator Starter Kit',
		'tag'         => 'No Face Needed',
		'price'       => '₹999',
		'description' => 'The complete Instagram system for building a faceless content business and income.',
		'image'       => 'faceless-creator-kit.jpg',
		'accent'      => 'brand',
	),
	array(
		'name'        => 'The Digital Entrepreneur Planner 2026',
		'tag'         => 'Planner',
		'price'       => '₹999',
		'description' => 'The all-in-one business planning and productivity system for entrepreneurs in 2026.',
		'image'       => 'entrepreneur-planner.jpg',
		'accent'      => 'accent',
	),
	array(
		'name'        => 'The Viral Hook Vault',
		'tag'         => '1,000 Hooks',
		'price'       => '₹999',
		'description' => '1,000 scroll-stopping hooks for Instagram, TikTok, YouTube and LinkedIn — turn ideas into viral content.',
		'image'       => 'viral-hook-vault.jpg',
		'accent'      => 'brand',
	),
	array(
		'name'        => 'Instagram Growth Blueprint 2026',
		'tag'         => '30-Day System',
		'price'       => '₹999',
		'description' => 'The 30-day Instagram growth system with 10 modules, a content calendar, trackers and 10 premium bonuses.',
		'image'       => 'instagram-growth-blueprint.jpg',
		'accent'      => 'cyan',
	),
	array(
		'name'        => 'The AI Digital Marketer’s Prompt Vault',
		'tag'         => '530+ Prompts',
		'price'       => '₹999',
		'description' => '530+ ready-to-use AI prompts with marketing workflows, templates and cheat sheets for every skill level.',
		'image'       => 'ai-prompt-vault.jpg',
		'accent'      => 'accent',
	),
	array(
		'name'        => 'The Complete Meditation Mastery Program',
		'tag'         => '8–10 Weeks',
		'price'       => '₹999',
		'description' => 'An 8–10 week self-paced meditation course with video lessons, guided meditations and lifetime access.',
		'image'       => 'meditation-mastery.jpg',
		'accent'      => 'brand',
	),
);

$testimonials = array(
	array(
		'quote' => 'SriSpark transformed our Instagram — followers grew 3× in 4 months and sales doubled. Maheswari is a gem!',
		'name'  => 'Priya R.',
		'role'  => 'Founder, Bloom Boutique',
	),
	array(
		'quote' => 'Our Google rankings went from page 5 to top 3 for all key terms. Genuine results, not just promises.',
		'name'  => 'Karthik S.',
		'role'  => 'CEO, UrbanFit Gym',
	),
	array(
		'quote' => 'Beautiful website, smart ads and friendly support. Worth every rupee.',
		'name'  => 'Anitha M.',
		'role'  => 'Marketing Lead, Sparkle Cafe',
	),
	array(
		'quote' => 'Backlinks and content strategy brought 70% more organic traffic in 90 days.',
		'name'  => 'Rajesh K.',
		'role'  => 'Owner, TechMart',
	),
	array(
		'quote' => 'The logo and brand kit they designed got us so many compliments. Premium feel.',
		'name'  => 'Divya L.',
		'role'  => 'Co-founder, Glow Studio',
	),
	array(
		'quote' => 'Best digital marketing partner in Chennai. Reports are clear and ROI is real.',
		'name'  => 'Vignesh P.',
		'role'  => 'Director, Shoreline Resorts',
	),
);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Shop Instagram templates, presets and growth kits from SriSpark Digital Tech. Order by WhatsApp and pay securely through GPay.">
	<meta property="og:title" content="SriSpark Digital Tech — Digital Products">
	<meta property="og:description" content="Premium creator templates, presets and growth kits delivered directly to you.">
	<meta property="og:type" content="website">
	<meta name="twitter:card" content="summary_large_image">
	<link rel="icon" href="<?php echo esc_url( get_theme_file_uri( 'assets/favicon.svg' ) ); ?>">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="page">
	<div class="ambient ambient-brand" aria-hidden="true"></div>
	<div class="ambient ambient-accent" aria-hidden="true"></div>

	<header class="site-nav">
		<nav class="nav-inner glass" aria-label="<?php esc_attr_e( 'Main navigation', 'srispark-digital' ); ?>">
			<a class="brand" href="#top">
				<span class="brand-mark gradient-brand">S</span>
				<span>SriSpark <small>Digital Tech</small></span>
			</a>
			<div class="nav-links">
				<a href="#products"><?php esc_html_e( 'Products', 'srispark-digital' ); ?></a>
				<a href="#how"><?php esc_html_e( 'How it works', 'srispark-digital' ); ?></a>
				<a href="#reviews"><?php esc_html_e( 'Reviews', 'srispark-digital' ); ?></a>
				<a href="#pay"><?php esc_html_e( 'Pay', 'srispark-digital' ); ?></a>
			</div>
			<a class="btn btn-hero" href="https://instagram.com/sri_spark_digital" target="_blank" rel="noreferrer">
				<?php echo srispark_icon( 'instagram' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<span><?php esc_html_e( 'Order on Instagram', 'srispark-digital' ); ?></span>
			</a>
		</nav>
	</header>

	<section class="hero" id="top">
		<div class="animate-fade-up">
			<span class="hero-badge"><span class="dot"><?php echo srispark_icon( 'sparkles' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span> <?php esc_html_e( 'Digital products · delivered online', 'srispark-digital' ); ?></span>
			<h1 class="hero-title"><?php esc_html_e( 'Spark your brand.', 'srispark-digital' ); ?><br><span class="text-gradient"><?php esc_html_e( 'Scale your business.', 'srispark-digital' ); ?></span></h1>
			<p class="hero-sub"><?php esc_html_e( 'Premium templates, presets and growth kits designed in Chennai and delivered directly to you. Created by Maheswari S.', 'srispark-digital' ); ?></p>
			<div class="hero-actions">
				<a class="btn btn-hero btn-lg" href="#products"><?php echo srispark_icon( 'shop' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> <?php esc_html_e( 'Shop products', 'srispark-digital' ); ?></a>
				<a class="btn btn-glass btn-lg" href="#pay"><?php esc_html_e( 'See payment details', 'srispark-digital' ); ?></a>
			</div>
			<div class="hero-stats">
				<div class="stat"><b>50+</b><span><?php esc_html_e( 'Happy clients', 'srispark-digital' ); ?></span></div>
				<div class="stat"><b>120+</b><span><?php esc_html_e( 'Projects delivered', 'srispark-digital' ); ?></span></div>
				<div class="stat"><b>4.9★</b><span><?php esc_html_e( 'Average rating', 'srispark-digital' ); ?></span></div>
			</div>
		</div>
		<div class="hero-visual">
			<div class="hero-frame glass">
				<img src="<?php echo $img( 'instagram-storefront-hero.jpg' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" alt="<?php esc_attr_e( 'Smartphone displaying a curated digital product storefront', 'srispark-digital' ); ?>" width="1024" height="1280" fetchpriority="high">
			</div>
			<div class="hero-chip glass">
				<small><?php esc_html_e( 'Easy ordering', 'srispark-digital' ); ?></small>
				<b><?php esc_html_e( 'WhatsApp + GPay', 'srispark-digital' ); ?></b>
			</div>
		</div>
	</section>

	<section class="section" id="products">
		<div class="section-head">
			<div>
				<p class="eyebrow"><?php esc_html_e( 'Launch collection', 'srispark-digital' ); ?></p>
				<h2 class="section-title"><?php esc_html_e( 'Digital products for creators', 'srispark-digital' ); ?></h2>
				<p><?php esc_html_e( 'Choose a kit and order it directly through WhatsApp.', 'srispark-digital' ); ?></p>
			</div>
			<a class="section-link" href="https://instagram.com/sri_spark_digital" target="_blank" rel="noreferrer"><?php esc_html_e( 'View Instagram →', 'srispark-digital' ); ?></a>
		</div>
		<div class="products-grid">
			<?php foreach ( $products as $product ) : ?>
				<article class="product-card glass">
					<img src="<?php echo $img( $product['image'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" alt="<?php echo esc_attr( $product['name'] . ' digital product preview' ); ?>" width="1024" height="1024" loading="lazy">
					<div class="product-body">
						<div class="product-top">
							<h3><?php echo esc_html( $product['name'] ); ?></h3>
							<span class="tag tag-<?php echo esc_attr( $product['accent'] ); ?>"><?php echo esc_html( $product['tag'] ); ?></span>
						</div>
						<p class="product-desc"><?php echo esc_html( $product['description'] ); ?></p>
						<div class="product-foot">
							<span class="price-wrap">
								<span class="price-label"><?php esc_html_e( 'Starting from', 'srispark-digital' ); ?></span>
								<span class="price"><?php echo esc_html( $product['price'] ); ?></span>
							</span>
							<a class="btn btn-glass" href="<?php echo esc_url( srispark_whatsapp_link( $product['name'] ) ); ?>" target="_blank" rel="noreferrer">
								<?php echo srispark_icon( 'whatsapp' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
								<?php esc_html_e( 'Order', 'srispark-digital' ); ?>
							</a>
						</div>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</section>

	<section class="section" id="how">
		<div class="how-grid">
			<div class="how-card glass">
				<h2 class="section-title"><?php esc_html_e( 'How to buy', 'srispark-digital' ); ?></h2>
				<div class="step">
					<span class="step-num">1</span>
					<div>
						<h3><?php esc_html_e( 'Choose your product', 'srispark-digital' ); ?></h3>
						<p><?php esc_html_e( 'Tap Order on the product you want to open a ready-to-send WhatsApp message.', 'srispark-digital' ); ?></p>
					</div>
				</div>
				<div class="step">
					<span class="step-num">2</span>
					<div>
						<h3><?php esc_html_e( 'Pay through GPay', 'srispark-digital' ); ?></h3>
						<p><?php esc_html_e( 'Send the exact product amount to 9842182212 and save your payment screenshot.', 'srispark-digital' ); ?></p>
					</div>
				</div>
				<div class="step">
					<span class="step-num">3</span>
					<div>
						<h3><?php esc_html_e( 'Confirm and receive', 'srispark-digital' ); ?></h3>
						<p><?php esc_html_e( 'Share the screenshot on WhatsApp. Your digital files will be sent after confirmation.', 'srispark-digital' ); ?></p>
					</div>
				</div>
			</div>
			<div class="pay-card" id="pay">
				<div class="pay-inner">
					<p class="eyebrow"><?php esc_html_e( 'Payment details', 'srispark-digital' ); ?></p>
					<h2 class="section-title"><?php esc_html_e( 'Pay with Google Pay', 'srispark-digital' ); ?></h2>
					<p class="lead"><?php esc_html_e( 'Use this mobile number for your payment.', 'srispark-digital' ); ?></p>
					<div class="gpay-box glass">
						<small><?php esc_html_e( 'GPay number', 'srispark-digital' ); ?></small>
						<p class="gpay-number">98421 82212</p>
						<div class="gpay-foot">
							<span class="gpay-meta"><?php esc_html_e( 'Google Pay', 'srispark-digital' ); ?></span>
							<button class="btn btn-glass js-copy-gpay" type="button" data-gpay="9842182212">
								<?php echo srispark_icon( 'copy' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
								<span><?php esc_html_e( 'Copy', 'srispark-digital' ); ?></span>
							</button>
						</div>
					</div>
					<a class="btn btn-glass btn-lg pay-btn" href="<?php echo esc_url( srispark_whatsapp_link() ); ?>" target="_blank" rel="noreferrer">
						<?php echo srispark_icon( 'whatsapp' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php esc_html_e( 'Confirm on WhatsApp', 'srispark-digital' ); ?>
					</a>
					<p class="pay-note"><?php esc_html_e( 'Please verify the number before paying. Digital products are delivered after payment confirmation.', 'srispark-digital' ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<section class="section" id="reviews">
		<p class="eyebrow"><?php esc_html_e( 'Loved by clients', 'srispark-digital' ); ?></p>
		<h2 class="section-title"><?php esc_html_e( 'What our clients say', 'srispark-digital' ); ?></h2>
		<div class="reviews-grid">
			<?php foreach ( $testimonials as $testimonial ) : ?>
				<figure class="review-card glass">
					<div class="stars" aria-label="<?php esc_attr_e( '5 out of 5 stars', 'srispark-digital' ); ?>">★★★★★</div>
					<blockquote>“<?php echo esc_html( $testimonial['quote'] ); ?>”</blockquote>
					<figcaption class="review-person">
						<span class="avatar gradient-brand"><?php echo esc_html( substr( $testimonial['name'], 0, 1 ) ); ?></span>
						<span>
							<b><?php echo esc_html( $testimonial['name'] ); ?></b>
							<span><?php echo esc_html( $testimonial['role'] ); ?></span>
						</span>
					</figcaption>
				</figure>
			<?php endforeach; ?>
		</div>
	</section>

	<footer class="site-footer">
		<div class="footer-card glass">
			<div class="footer-top">
				<div>
					<h2><?php esc_html_e( 'Let’s spark your brand', 'srispark-digital' ); ?></h2>
					<div class="contact-list">
						<a href="mailto:sssm3212530@gmail.com"><?php echo srispark_icon( 'mail' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> sssm3212530@gmail.com</a>
						<a href="tel:+918122772099"><?php echo srispark_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> +91 81227 72099</a>
						<a href="tel:+917010591538"><?php echo srispark_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> +91 70105 91538</a>
						<span><?php echo srispark_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?> Chennai, Tamil Nadu</span>
					</div>
				</div>
				<div class="socials">
					<a class="btn btn-glass btn-icon" aria-label="Instagram" title="Instagram" href="https://instagram.com/sri_spark_digital" target="_blank" rel="noreferrer"><?php echo srispark_icon( 'instagram' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
					<a class="btn btn-glass btn-icon" aria-label="Facebook" title="Facebook" href="https://www.facebook.com/profile.php?id=61584602291869" target="_blank" rel="noreferrer"><?php echo srispark_icon( 'facebook' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
					<a class="btn btn-glass btn-icon" aria-label="X" title="X" href="https://twitter.com/MAHI67507" target="_blank" rel="noreferrer"><span style="font-family:var(--font-display);font-weight:700;">X</span></a>
					<a class="btn btn-glass btn-icon" aria-label="LinkedIn" title="LinkedIn" href="https://www.linkedin.com/in/srispark-digital-11579237a" target="_blank" rel="noreferrer"><?php echo srispark_icon( 'linkedin' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
					<a class="btn btn-glass btn-icon" aria-label="WhatsApp" title="WhatsApp" href="https://wa.me/919842182212" target="_blank" rel="noreferrer"><?php echo srispark_icon( 'whatsapp' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
				</div>
			</div>
			<div class="footer-bottom">
				<p>© <?php echo esc_html( gmdate( 'Y' ) ); ?> SriSpark Digital Tech. <?php esc_html_e( 'All rights reserved.', 'srispark-digital' ); ?></p>
				<p><?php esc_html_e( 'Spark your brand. Scale your business.', 'srispark-digital' ); ?></p>
			</div>
		</div>
	</footer>
</div>



<?php wp_footer(); ?>
</body>
</html>
